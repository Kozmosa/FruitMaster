Mihai Oltean, Fruits 360 dataset: new research directions, Technical report, 2021.

https://www.researchgate.net/publication/354535752_Fruits_360_dataset_new_research_directions