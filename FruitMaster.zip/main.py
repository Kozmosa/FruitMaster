def main():
    print("Hello from fruitmaster!")


if __name__ == "__main__":
    main()
